import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pac-man',
  templateUrl: './pac-man.component.html',
  styleUrls: ['./pac-man.component.css']
})
export class PacManComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
