import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { TypingCarouselComponent } from './typing-carousel/typing-carousel.component';

import { TypingCarouselDirective } from './shared/directive/typing-carousel.directive';
import { MobileHideDirective } from './shared/directive/mobile-hide.directive';
import { MobileTestComponent } from './mobile-test/mobile-test.component';
import { PacManComponent } from './pac-man/pac-man.component';
import { SupermanLoadingComponent } from './superman-loading/superman-loading.component';
import { EvilLoadingComponent } from './evil-loading/evil-loading.component';
import { NavbarComponent } from './navbar/navbar.component';

import { MaterializeModule } from 'angular2-materialize';
import { MaterialModule } from '@angular/material';
import 'hammerjs';

import { routing } from './app.routing';
import { HomeComponent } from './home/home.component'

@NgModule({
  declarations: [
    AppComponent,
    TypingCarouselComponent,
    TypingCarouselDirective,
    MobileHideDirective,
    MobileTestComponent,
    PacManComponent,
    SupermanLoadingComponent,
    EvilLoadingComponent,
    NavbarComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MaterializeModule,
    MaterialModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
