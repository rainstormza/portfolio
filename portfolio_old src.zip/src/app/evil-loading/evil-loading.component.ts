import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evil-loading',
  templateUrl: './evil-loading.component.html',
  styleUrls: ['./evil-loading.component.css']
})
export class EvilLoadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
