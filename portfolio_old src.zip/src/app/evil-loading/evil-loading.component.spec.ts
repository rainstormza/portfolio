import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvilLoadingComponent } from './evil-loading.component';

describe('EvilLoadingComponent', () => {
  let component: EvilLoadingComponent;
  let fixture: ComponentFixture<EvilLoadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvilLoadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvilLoadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
