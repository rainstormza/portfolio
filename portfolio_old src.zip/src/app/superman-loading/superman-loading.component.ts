import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superman-loading',
  templateUrl: './superman-loading.component.html',
  styleUrls: ['./superman-loading.component.css']
})
export class SupermanLoadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
